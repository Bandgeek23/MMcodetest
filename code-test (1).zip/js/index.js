// Information to reach API
const api = 'https://jsonplaceholder.typicode.com';
const userParams = '/users/';
const postParams = '/posts?userId=';


// Selects page elements
const inputField = document.querySelector('#input');
const submit = document.querySelector('#submit');
const responseField = document.querySelector('#responseField');

//Uses search to pull specific API page for user
const getUsers = () => {
const numberQuery = inputField.value;
const userEndpoint = `${api}${userParams}${numberQuery}`;

function getElement(id) {
  return document.getElementById(id);
}
//Fetches User info from API
fetch(userEndpoint)
.then((res) => {
  if (res.ok) {
    return res.json();
  }
  else {
    throw new Error ('user ID not found');
  }
})
  .then((res) => {
  const data = res;
  const companyName = res.company.name
  const companyCatchPhrase = res.company.catchPhrase
  getElement('name').innerHTML =  data.name;
  getElement('email').innerHTML = data.email;
  getElement('company name').innerHTML = 'Company Name: ' + data.company.name;
  getElement('company catch phrase').innerHTML = 'Company Catchphrase: ' + data.company.catchPhrase}) 
 .catch(function(error) {
    console.log(error);
  });  
}


//Uses search to pull post data
const getPosts = () => {
const numberQuery = inputField.value;
const postEndpoint = `${api}${postParams}${numberQuery}`;
function createNode(element) {
      return document.createElement(element);
  }

  function append(parent, el) {
    return parent.appendChild(el);
  }
  const ul = document.getElementById('posts');
  
  //Fetches post from API
  fetch(postEndpoint)
  .then((resp) => resp.json())
  .then(function(res) {
   let posts = res;
    return posts.map(function(posts) {
let p = createNode('p');
let title = createNode('title');
let span = createNode('span');
span.innerHTML = `<strong>Title:</strong> ${posts.title} <br> <br> <strong>Body:</strong> ${posts.body}`;
      append(p, title);
      append(p, span);
      append(ul, p);
    })
  })
  .catch(function(error) {
    console.log(error);
  });   
}

// Clears previous results and display results to webpage for users
const displayUsers = (event) => {
  event.preventDefault();
  while(responseField.firstChild){
    responseField.removeChild(responseField.firstChild);
  }
  getUsers();
};

submit.addEventListener('click', displayUsers);


// Clears previous results and display results to webpage for posts 
const displayPosts = (event) => {
  event.preventDefault();
  while(posts.firstChild){
   posts.removeChild(posts.firstChild);
  }
  getPosts();
};

submit.addEventListener('click', displayPosts);